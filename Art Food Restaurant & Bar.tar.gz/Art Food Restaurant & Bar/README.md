# Art Food Restaurant & Bar

A modern, responsive restaurant website built using HTML, CSS, and JavaScript.

## About the Project

Art Food Restaurant & Bar is a restaurant landing page designed to provide visitors with an attractive and user-friendly experience. The website showcases restaurant information, food offerings, and contact details through a clean and responsive interface.

## Features

- Responsive design for desktop, tablet, and mobile devices
- Modern and clean user interface
- Interactive navigation menu
- Restaurant information and presentation
- Contact form with name and email fields
- Organized layout and typography
- Multi-language support

## Technologies Used

- HTML5
- CSS3
- JavaScript
- Google Fonts
- Font Awesome

## Responsive Design

The website has been tested on:

- Desktop
- Tablet
- Mobile devices

## Project Structure

```text
restaurant-landing-page/
│
├── index.html
├── css/
│   └── style.css
├── js/
│   ├── script.js
│   └── translations.js
└── README.md
```

## How to Run

1. Clone this repository:

   ```bash
   git clone YOUR_REPOSITORY_URL
   ```

2. Open the project folder.
3. Open `index.html` in your browser.

## Project Goals

This project was created to improve my practical skills in front-end development, responsive web design, and website customization.

## Developer

**Masihullah Yaseen**

Aspiring Web Developer | Learning Front-End Development

## License

This project is intended for educational and portfolio purposes.